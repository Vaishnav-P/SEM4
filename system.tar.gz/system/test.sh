#!/bin/bash

echo "Program 1..Addition of two numbers";

echo "ENter two numbers";

read num1;

read num2;
  
echo "sum:"$(($num1 + $num2));
