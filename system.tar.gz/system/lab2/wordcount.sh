echo "Enter string "
read str
count=` echo $str | wc -w `
echo "No of words = $count"